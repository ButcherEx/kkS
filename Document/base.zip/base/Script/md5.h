/*******************************************************************************

Copyright 2010 by backkom. All rights reserved.
This software is the confidential and proprietary information of backkom.
('Confidential Information'). You shall not disclose such Confidential -
Information and shall use it only in accordance with the terms of the - 
license agreement you entered into with backkom.

*******************************************************************************/

#ifndef __MD5__
#define __MD5__

#ifdef __cplusplus
extern "C" {
#endif  /** __cplusplus */

SF_API VOID MyMD5(UCHAR *src, int nsrc, UCHAR code[33]);

#ifdef __cplusplus
}
#endif /** __cplusplus */


#endif /* __MD5__ */
