/*
NAME
   dbpCopy.cpp

DESCRIPTION
   Stub file to enable building of dbgCopy.lib replacement for dbgHelp.lib

   $Id: dbgCopy.cpp,v 1.1 2005/05/03 19:52:01 Roger Exp $
*/

#define API void __stdcall

#define ARG_0  () {}
#define ARG_4  (int) {}
#define ARG_8  (int,int) {}
#define ARG_12 (int,int,int) {}
#define ARG_16 (int,int,int,int) {}
#define ARG_20 (int,int,int,int,int) {}
#define ARG_24 (int,int,int,int,int,int) {}
#define ARG_28 (int,int,int,int,int,int,int) {}
#define ARG_32 (int,int,int,int,int,int,int,int) {}
#define ARG_36 (int,int,int,int,int,int,int,int,int) {}
#define ARG_40 (int,int,int,int,int,int,int,int,int,int) {}
#define ARG_44 (int,int,int,int,int,int,int,int,int,int,int) {}
#define ARG_48 (int,int,int,int,int,int,int,int,int,int,int,int) {}

extern "C" {
#include "build\dbgcopy.include"
}
